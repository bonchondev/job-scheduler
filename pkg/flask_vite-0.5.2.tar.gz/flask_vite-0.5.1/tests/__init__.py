# Copyright (c) 2022-2024, Abilian SAS
#
# SPDX-License-Identifier: MIT

"""Unit test package for flask_vite."""
